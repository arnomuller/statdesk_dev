#' Application Shiny
#'
#' Cette fonction permet de lancer l'application shiny dans un navigateur internet.
#' @param - no param
#' @export
#' @examples statdesk()
statdesk <- function(){


  # List of packages for session
  .packages = c("shiny", "shinyWidgets", "shinythemes", "fresh", "openxlsx", "dplyr", "sortable",
                "tidyr", "DT", "ggplot2", "colourpicker", "RColorBrewer", "plotly")

  # Install CRAN packages (if not already installed)
  .inst <- .packages %in% installed.packages()
  if(length(.packages[!.inst]) > 0) install.packages(.packages[!.inst])

  # Load packages into session
  lapply(.packages, require, character.only=TRUE)


  appDir <- system.file("statdesk_app", package = "statdesk")
  shiny::runApp(appDir, host = '0.0.0.0', port = 3838)
}


